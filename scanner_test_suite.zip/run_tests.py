"""
Sends every test ZIP to the running scanner and checks the result.

Start the scanner first (python or Docker), then:

    python run_tests.py
    python run_tests.py --url http://localhost:8000/tileset-scanner/
    python run_tests.py --only 3_sanitized_glb_xss
"""

import argparse
import io
import json
import struct
import sys
import urllib.error
import urllib.request
import uuid
import zipfile
from pathlib import Path

HERE = Path(__file__).parent / "test_zips"


def post_file(url, path):
    boundary = uuid.uuid4().hex
    data = path.read_bytes()
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{path.name}"\r\n'
        f"Content-Type: application/octet-stream\r\n\r\n"
    ).encode("utf-8") + data + f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers)


def bin_chunk(glb):
    json_len = struct.unpack_from("<I", glb, 12)[0]
    pos = 20 + json_len
    if pos + 8 > len(glb):
        return b""
    length = struct.unpack_from("<I", glb, pos)[0]
    return glb[pos + 8: pos + 8 + length]


def check(case, status, body):
    problems = []

    if status != case["status"]:
        problems.append(f"status {status}, expected {case['status']}")
        if status != 200:
            problems.append(body[:200].decode("utf-8", "replace"))
        return problems

    if status != 200:
        text = body.decode("utf-8", "replace")
        if case.get("error_contains") and case["error_contains"] not in text:
            problems.append(f"error should contain '{case['error_contains']}', got {text[:200]}")
        return problems

    z = zipfile.ZipFile(io.BytesIO(body))
    names = z.namelist()
    report = json.loads(z.read("report.json"))

    def expect_count(key, got):
        if key in case and case[key] != got:
            problems.append(f"{key}: {got}, expected {case[key]}")

    expect_count("removed_uris", len(report["removed_uris"]))
    expect_count("sanitized_glbs", len(report["sanitized_glbs"]))
    expect_count("not_scanned", len(report["not_scanned"]))

    if "removed_uri_locations" in case:
        got = sorted(r["location"] for r in report["removed_uris"])
        if got != sorted(case["removed_uri_locations"]):
            problems.append(f"removed uri locations {got}, expected {sorted(case['removed_uri_locations'])}")

    for file, locs in case.get("glb_removed", {}).items():
        entry = next((g for g in report["sanitized_glbs"] if g["file"] == file), None)
        got = sorted(entry["removed"]) if entry else []
        if got != sorted(locs):
            problems.append(f"{file} removed {got}, expected {sorted(locs)}")

    for name in case.get("absent_in_output", []):
        if any(n.endswith(name) for n in names):
            problems.append(f"{name} should not be in the output")

    for name in case.get("present_in_output", []):
        if not any(n.endswith(name) for n in names):
            problems.append(f"{name} missing from the output")

    for file, hexbin in case.get("glb_bin_equals", {}).items():
        path = next(n for n in names if n.endswith(file))
        if bin_chunk(z.read(path)).hex() != hexbin:
            problems.append(f"BIN chunk of {file} changed")

    return problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8000/tileset-scanner/")
    ap.add_argument("--only", help="run only cases whose path contains this text")
    args = ap.parse_args()

    cases = json.loads((HERE / "expected.json").read_text(encoding="utf-8"))
    if args.only:
        cases = [c for c in cases if args.only in c["zip"]]

    try:
        urllib.request.urlopen(args.url.rsplit("/", 2)[0] + "/docs", timeout=5)
    except Exception:
        print(f"Can't reach the scanner at {args.url}. Start it first (docker run ... or uvicorn main:app).")
        sys.exit(2)

    passed = failed = 0
    gaps_open, gaps_closed = [], []
    group = None

    for case in cases:
        folder = case["zip"].split("/")[0]
        if folder != group:
            group = folder
            print(f"\n== {folder}")

        status, body, _ = post_file(args.url, HERE / case["zip"])
        problems = check(case, status, body)
        name = case["zip"].split("/")[1]

        if case.get("gap"):
            # a gap "passes" when the scanner still lets it through unchanged
            if problems:
                gaps_closed.append(name)
                print(f"  CLOSED  {name}  (scanner now catches this)")
            else:
                gaps_open.append(name)
                print(f"  GAP     {name}  {case['note']}")
            continue

        if problems:
            failed += 1
            print(f"  FAIL    {name}  {case['note']}")
            for p in problems:
                print(f"            - {p}")
        else:
            passed += 1
            print(f"  PASS    {name}")

    print(f"\n{passed} passed, {failed} failed, {len(gaps_open)} known gaps still open")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()

"""
Builds test ZIPs for the 3D Tiles Security Scanner.

Every ZIP targets one check in the scanner. The expected result of each ZIP
is written to expected.json, which run_tests.py uses.

    python make_test_zips.py
"""

import io
import json
import os
import shutil
import stat
import struct
import zipfile
from pathlib import Path

OUT = Path("test_zips")
CASES = []


# ---------------------------------------------------------------- helpers

def triangle_bin():
    # 3 vertices, vec3 float = 36 bytes
    return struct.pack("<9f", 0, 0, 0, 1, 0, 0, 0, 1, 0)


def base_gltf(bin_length=36):
    return {
        "asset": {"version": "2.0", "generator": "scanner-test"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [{"mesh": 0, "name": "door"}],
        "meshes": [{"primitives": [{"attributes": {"POSITION": 0}}]}],
        "accessors": [{
            "bufferView": 0, "componentType": 5126, "count": 3, "type": "VEC3",
            "min": [0, 0, 0], "max": [1, 1, 0],
        }],
        "bufferViews": [{"buffer": 0, "byteOffset": 0, "byteLength": 36}],
        "buffers": [{"byteLength": bin_length}],
    }


def pad(data, fill):
    return data + fill * ((4 - len(data) % 4) % 4)


def chunk(data, ctype):
    return struct.pack("<I4s", len(data), ctype) + data


def glb(gltf=None, bin_data=None, json_bytes=None, version=2, magic=b"glTF",
        length_delta=0, extra_chunks=b""):
    """Build a GLB. Arguments let a test break one thing at a time."""
    if gltf is None:
        gltf = base_gltf()
    if bin_data is None:
        bin_data = triangle_bin()
    if json_bytes is None:
        json_bytes = json.dumps(gltf).encode("utf-8")
    body = chunk(pad(json_bytes, b" "), b"JSON")
    if bin_data != b"" and bin_data is not False:
        body += chunk(pad(bin_data, b"\x00"), b"BIN\x00")
    body += extra_chunks
    total = 12 + len(body) + length_delta
    return struct.pack("<4sII", magic, version, total) + body


def tileset(root=None, **top):
    ts = {
        "asset": {"version": "1.1"},
        "geometricError": 100,
        "root": root if root is not None else {
            "boundingVolume": {"box": [0, 0, 0, 10, 0, 0, 0, 10, 0, 0, 0, 10]},
            "geometricError": 10,
            "refine": "ADD",
            "content": {"uri": "tiles/a.glb"},
        },
    }
    ts.update(top)
    return ts


def tile(uri=None, children=None):
    t = {
        "boundingVolume": {"box": [0, 0, 0, 5, 0, 0, 0, 5, 0, 0, 0, 5]},
        "geometricError": 1,
    }
    if uri is not None:
        t["content"] = {"uri": uri}
    if children:
        t["children"] = children
    return t


def root_with(children, uri="tiles/a.glb"):
    r = tile(uri, children)
    r["geometricError"] = 10
    r["refine"] = "ADD"
    return r


def write_zip(name, files, raw_entries=None):
    """files: {arcname: bytes|str|dict}. raw_entries: list of (ZipInfo, bytes)."""
    path = OUT / name
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for arc, data in files.items():
            if isinstance(data, (dict, list)):
                data = json.dumps(data, indent=2)
            if isinstance(data, str):
                data = data.encode("utf-8")
            z.writestr(arc, data)
        for info, data in raw_entries or []:
            z.writestr(info, data)
    return path


def case(folder, name, files=None, expect=None, note="", raw=None, raw_entries=None):
    (OUT / folder).mkdir(parents=True, exist_ok=True)
    rel = f"{folder}/{name}"
    if raw is not None:
        (OUT / rel).write_bytes(raw)
    else:
        write_zip(rel, files, raw_entries)
    CASES.append({"zip": rel, "note": note, **expect})


def ok_clean():
    return {"status": 200, "removed_uris": 0, "sanitized_glbs": 0}


def rejected(text):
    return {"status": 400, "error_contains": text}


GOOD = glb()


# ======================================================= 1. should pass clean

F = "1_clean"

case(F, "01_valid_simple.zip",
     {"tileset.json": tileset(), "tiles/a.glb": GOOD},
     ok_clean(), "Baseline: one tile, one clean GLB")

case(F, "02_valid_tree.zip",
     {"tileset.json": tileset(root_with([
         tile("tiles/b.glb", [tile("tiles/c.glb", [tile("tiles/d.glb")])]),
         tile("tiles/e.glb"),
     ])),
      "tiles/a.glb": GOOD, "tiles/b.glb": GOOD, "tiles/c.glb": GOOD,
      "tiles/d.glb": GOOD, "tiles/e.glb": GOOD},
     ok_clean(), "Deep tile tree, all references valid")

case(F, "03_valid_tileset_in_subfolder.zip",
     {"data/city/tileset.json": tileset(), "data/city/tiles/a.glb": GOOD},
     ok_clean(), "tileset.json is not at the ZIP root")

case(F, "04_valid_shared_glb.zip",
     {"tileset.json": tileset(root_with([tile("tiles/a.glb"), tile("tiles/a.glb")])),
      "tiles/a.glb": GOOD},
     ok_clean(), "The same GLB is used by three tiles, must appear once in the output")

case(F, "05_valid_uri_with_spaces.zip",
     {"tileset.json": tileset(root_with([], uri="tiles/my%20model.glb")),
      "tiles/my model.glb": GOOD},
     ok_clean(), "Percent-encoded space in the uri")

case(F, "06_valid_no_bin_chunk.zip",
     {"tileset.json": tileset(),
      "tiles/a.glb": glb({"asset": {"version": "2.0"}, "nodes": [{"name": "empty"}]}, bin_data=b"")},
     ok_clean(), "GLB with JSON only, no buffers and no BIN chunk (allowed)")

case(F, "07_valid_tile_without_content.zip",
     {"tileset.json": tileset(root_with([tile(None, [tile("tiles/a.glb")])], uri=None)),
      "tiles/a.glb": GOOD},
     ok_clean(), "Root and a child have no content, only a grandchild does")

case(F, "08_unreferenced_extra_files.zip",
     {"tileset.json": tileset(), "tiles/a.glb": GOOD,
      "evil.html": "<script>alert(1)</script>", "run.exe": b"MZ\x90\x00",
      "notes/readme.txt": "hello"},
     {**ok_clean(), "absent_in_output": ["evil.html", "run.exe", "notes/readme.txt"]},
     "Files the tileset doesn't use must not reach the output ZIP")

case(F, "09_other_content_types.zip",
     {"tileset.json": tileset(root_with([tile("tiles/b.b3dm"), tile("textures/t.png")])),
      "tiles/a.glb": GOOD, "tiles/b.b3dm": b"b3dm" + b"\x00" * 24, "textures/t.png": b"\x89PNG\r\n\x1a\n"},
     {**ok_clean(), "not_scanned": 2},
     "B3DM and PNG are copied and listed as not_scanned")

case(F, "בדיקה עברית.zip",
     {"tileset.json": tileset(), "tiles/a.glb": GOOD},
     ok_clean(), "Hebrew name with a space: checks the Content-Disposition header")


# ================================================ 2. should be sanitized: tileset uris

F = "2_sanitized_tileset"


def bad_uri_case(name, bad, note):
    case(F, name,
         {"tileset.json": tileset(root_with([tile(bad), tile("tiles/b.glb")])),
          "tiles/a.glb": GOOD, "tiles/b.glb": GOOD},
         {"status": 200, "removed_uris": 1, "removed_uri_locations": ["root.children[0].content"]},
         note)


bad_uri_case("10_uri_external_https.zip", "https://evil.example.com/x.glb", "External https uri (SSRF)")
bad_uri_case("11_uri_external_http_internal_ip.zip", "http://169.254.169.254/latest/meta-data", "Cloud metadata address")
bad_uri_case("12_uri_protocol_relative.zip", "//evil.example.com/x.glb", "Protocol-relative uri, no scheme but a host")
bad_uri_case("13_uri_file_scheme.zip", "file:///etc/passwd", "file:// scheme")
bad_uri_case("14_uri_javascript.zip", "javascript:alert(1)", "javascript: as a content uri")
bad_uri_case("15_uri_data_scheme.zip", "data:model/gltf-binary;base64,Z2xURg==", "data: uri")
bad_uri_case("16_uri_windows_drive.zip", "C:/Windows/System32/x.glb", "Drive letter, parsed as scheme 'c'")
bad_uri_case("17_uri_path_traversal.zip", "../../etc/passwd", "../ leaves the ZIP folder")
bad_uri_case("18_uri_encoded_traversal.zip", "%2e%2e/%2e%2e/secret.glb", "Encoded ../, must be decoded before the check")
bad_uri_case("19_uri_double_encoded.zip", "%252e%252e/secret.glb", "Double encoding: decodes once to %2e%2e/, file doesn't exist")
bad_uri_case("20_uri_absolute.zip", "/etc/passwd", "Absolute path")
bad_uri_case("21_uri_backslash.zip", "..\\..\\x.glb", "Windows backslashes")
bad_uri_case("22_uri_missing_file.zip", "tiles/missing.glb", "Referenced file is not in the ZIP")
bad_uri_case("23_uri_empty.zip", "", "Empty uri. FAILS on the current code: \"\" or content.get(\"url\") gives None, so the uri is never checked")
bad_uri_case("24_uri_points_to_folder.zip", "tiles", "uri points to a folder, not a file")

case(F, "25_uri_legacy_url_key.zip",
     {"tileset.json": tileset(root_with([{**tile(None), "content": {"url": "https://evil.example.com/x.glb"}}])),
      "tiles/a.glb": GOOD},
     {"status": 200, "removed_uris": 1, "removed_uri_locations": ["root.children[0].content"]},
     "Old 3D Tiles 0.0 'url' key instead of 'uri'")

case(F, "26_uri_bad_on_root.zip",
     {"tileset.json": tileset(root_with([tile("tiles/b.glb")], uri="https://evil.example.com/root.glb")),
      "tiles/b.glb": GOOD},
     {"status": 200, "removed_uris": 1, "removed_uri_locations": ["root.content"]},
     "The root tile's own content is bad, its child is fine")

case(F, "27_uri_bad_deep_in_tree.zip",
     {"tileset.json": tileset(root_with([tile("tiles/b.glb", [tile("tiles/c.glb", [tile("../../deep.glb")])])])),
      "tiles/a.glb": GOOD, "tiles/b.glb": GOOD, "tiles/c.glb": GOOD},
     {"status": 200, "removed_uris": 1,
      "removed_uri_locations": ["root.children[0].children[0].children[0].content"]},
     "Bad uri four levels deep, tests the recursive walk")

case(F, "28_uri_many_bad_siblings.zip",
     {"tileset.json": tileset(root_with([
         tile("https://evil.example.com/0.glb"), tile("tiles/b.glb"),
         tile("../2.glb"), tile("tiles/c.glb"), tile("/4.glb")])),
      "tiles/a.glb": GOOD, "tiles/b.glb": GOOD, "tiles/c.glb": GOOD},
     {"status": 200, "removed_uris": 3, "present_in_output": ["tiles/b.glb", "tiles/c.glb"],
      "removed_uri_locations": ["root.children[0].content", "root.children[2].content", "root.children[4].content"]},
     "Bad uris at indexes 0, 2, 4: tests deleting from the end of the list")

case(F, "29_uri_all_bad.zip",
     {"tileset.json": tileset(root_with([tile("https://a.example.com/x.glb"), tile("../y.glb")],
                                        uri="//b.example.com/z.glb"))},
     {"status": 200, "removed_uris": 3},
     "Every reference is bad, the output keeps an empty tile tree")


# ================================================== 3. should be sanitized: GLB XSS

F = "3_sanitized_glb_xss"


def xss_case(name, mutate, locations, note):
    g = base_gltf()
    mutate(g)
    case(F, name,
         {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
         {"status": 200, "sanitized_glbs": 1, "glb_removed": {"tiles/a.glb": locations}},
         note)


xss_case("30_xss_script_in_generator.zip",
         lambda g: g["asset"].update(generator="<script>alert(1)</script>"),
         ["glb_json.asset.generator"], "<script> in asset.generator")
xss_case("31_xss_event_handler_in_node_name.zip",
         lambda g: g["nodes"][0].update(name="door onload=alert(1)"),
         ["glb_json.nodes[0].name"], "onload= in a node name")
xss_case("32_xss_javascript_uri_in_extras.zip",
         lambda g: g["nodes"][0].update(extras={"link": "javascript:alert(document.cookie)"}),
         ["glb_json.nodes[0].extras.link"], "javascript: in extras")
xss_case("33_xss_img_onerror.zip",
         lambda g: g.update(materials=[{"name": "<img src=x onerror=alert(1)>"}]),
         ["glb_json.materials[0].name"], "<img onerror=> in a material name")
xss_case("34_xss_mixed_case.zip",
         lambda g: g["asset"].update(copyright="<ScRiPt>alert(1)</sCrIpT>"),
         ["glb_json.asset.copyright"], "Mixed case must still match")
xss_case("35_xss_whitespace_tricks.zip",
         lambda g: g["nodes"][0].update(name="javascript   :alert(1)"),
         ["glb_json.nodes[0].name"], "Spaces before the colon")
xss_case("36_xss_space_after_bracket.zip",
         lambda g: g["asset"].update(generator="<  script>alert(1)</script>"),
         ["glb_json.asset.generator"], "Spaces after <")
xss_case("37_xss_in_extensions_used_list.zip",
         lambda g: g.update(extensionsUsed=["KHR_materials_unlit", "<script>x</script>"]),
         ["glb_json.extensionsUsed[1]"], "Removes one string from a list")
xss_case("38_xss_many_items_same_list.zip",
         lambda g: g.update(extensionsUsed=["<script>0", "KHR_a", "onclick=2", "KHR_b", "javascript:4"]),
         ["glb_json.extensionsUsed[0]", "glb_json.extensionsUsed[2]", "glb_json.extensionsUsed[4]"],
         "Three findings in one list: tests deleting from the end")
xss_case("39_xss_deeply_nested_extras.zip",
         lambda g: g["nodes"][0].update(extras={"a": {"b": [{"c": {"d": ["ok", "<script>deep</script>"]}}]}}),
         ["glb_json.nodes[0].extras.a.b[0].c.d[1]"], "Deep nesting of dicts and lists")
xss_case("40_xss_one_value_two_rules.zip",
         lambda g: g["asset"].update(generator="<script onload=x>javascript:y</script>"),
         ["glb_json.asset.generator"], "One string matches all three rules, must be removed once")
xss_case("41_xss_unicode_escaped_json.zip",
         lambda g: None, ["glb_json.asset.generator"],
         "\\u003cscript in the JSON text, json.loads turns it into <script>")
# 41 needs raw JSON text with \u003c escapes
g41 = base_gltf()
g41["asset"]["generator"] = "PLACEHOLDER"
text41 = json.dumps(g41).replace("PLACEHOLDER", "\\u003cscript\\u003ealert(1)\\u003c/script\\u003e")
write_zip(f"{F}/41_xss_unicode_escaped_json.zip",
          {"tileset.json": tileset(), "tiles/a.glb": glb(json_bytes=text41.encode())})

xss_case("42_xss_in_many_places.zip",
         lambda g: (g["asset"].update(generator="<script>1</script>"),
                    g["nodes"][0].update(name="x onmouseover=2"),
                    g["scenes"][0].update(name="javascript:3"),
                    g["meshes"][0].update(extras={"note": "<script>4</script>"})),
         ["glb_json.asset.generator", "glb_json.nodes[0].name",
          "glb_json.scenes[0].name", "glb_json.meshes[0].extras.note"],
         "Four findings in different parts of the JSON")

g = base_gltf()
g["nodes"][0]["name"] = "<script>shared</script>"
case(F, "43_xss_shared_glb.zip",
     {"tileset.json": tileset(root_with([tile("tiles/a.glb"), tile("tiles/a.glb")])),
      "tiles/a.glb": glb(g)},
     {"status": 200, "sanitized_glbs": 1, "glb_removed": {"tiles/a.glb": ["glb_json.nodes[0].name"]}},
     "Infected GLB used by three tiles: cleaned on the first visit, clean on the next ones")

g = base_gltf()
g["asset"]["generator"] = "<script>x</script>"
case(F, "44_xss_and_bad_uri_together.zip",
     {"tileset.json": tileset(root_with([tile("https://evil.example.com/x.glb")])),
      "tiles/a.glb": glb(g), "evil.html": "<script>alert(1)</script>"},
     {"status": 200, "removed_uris": 1, "sanitized_glbs": 1, "absent_in_output": ["evil.html"]},
     "Realistic attack: bad uri + infected GLB + stray HTML file")

g = base_gltf()
g["nodes"][0]["name"] = "only onload=x here"
case(F, "45_xss_bin_data_preserved.zip",
     {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
     {"status": 200, "sanitized_glbs": 1, "glb_bin_equals": {"tiles/a.glb": triangle_bin().hex()}},
     "After cleaning, the BIN chunk must be byte-for-byte the same")

xss_case("48_xss_svg_slash_onload.zip",
         lambda g: g["nodes"][0].update(name="<svg/onload=alert(1)>"),
         ["glb_json.nodes[0].name"], "'/onload=' with no space before 'on'")

xss_case("46_xss_false_positive.zip",
         lambda g: g["nodes"][0].update(extras={"status": "server online=yes"}),
         ["glb_json.nodes[0].extras.status"],
         "Harmless text 'online=yes' matches the event-handler rule and is removed (false positive)")

g = base_gltf()
g["nodes"][0]["name"] = "Station_online=true"
case("1_clean", "47_no_false_positive_underscore.zip",
     {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
     ok_clean(), "'_online=' has no word boundary before 'on', must NOT be flagged")


# ======================================================= 4. should be rejected: ZIP

F = "4_rejected_zip"

zi = zipfile.ZipInfo("../evil.txt")
case(F, "50_zip_slip_dotdot.zip", {"tileset.json": tileset(), "tiles/a.glb": GOOD},
     rejected("Unsafe path"), "Entry name ../evil.txt", raw_entries=[(zi, b"pwned")])

zi = zipfile.ZipInfo("tiles/../../evil.txt")
case(F, "51_zip_slip_nested.zip", {"tileset.json": tileset(), "tiles/a.glb": GOOD},
     rejected("Unsafe path"), "../ in the middle of the entry name", raw_entries=[(zi, b"pwned")])

zi = zipfile.ZipInfo("x")
zi.filename = "/tmp/evil.txt"
case(F, "52_zip_absolute_path.zip", {"tileset.json": tileset(), "tiles/a.glb": GOOD},
     rejected("Unsafe path"), "Absolute entry name /tmp/evil.txt", raw_entries=[(zi, b"pwned")])

zi = zipfile.ZipInfo("x")
zi.filename = "..\\..\\evil.txt"
case(F, "53_zip_backslash.zip", {"tileset.json": tileset(), "tiles/a.glb": GOOD},
     rejected("Unsafe path"), "Windows backslash entry name", raw_entries=[(zi, b"pwned")])

zi = zipfile.ZipInfo("tiles/link.glb")
zi.create_system = 3
zi.external_attr = (stat.S_IFLNK | 0o777) << 16
case(F, "54_zip_symlink.zip", {"tileset.json": tileset(), "tiles/a.glb": GOOD},
     rejected("Symbolic links"), "Symlink entry pointing to /etc/passwd", raw_entries=[(zi, b"/etc/passwd")])

# zipfile clears the encryption flag when writing, so set it in the bytes directly
buf = io.BytesIO()
with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as z:
    z.writestr("tileset.json", json.dumps(tileset()))
    z.writestr("tiles/a.glb", GOOD)
    z.writestr("tiles/secret.glb", b"x" * 64)
data = bytearray(buf.getvalue())
local = data.rfind(b"PK\x03\x04")    # local header of the last entry
central = data.rfind(b"PK\x01\x02")  # central header of the last entry
data[local + 6] |= 0x1
data[central + 8] |= 0x1
case(F, "55_zip_encrypted_flag.zip", None, rejected("Encrypted"),
     "Entry with the encryption flag set", raw=bytes(data))

case(F, "56_zip_bomb_ratio.zip",
     {"tileset.json": tileset(), "tiles/a.glb": GOOD, "padding.bin": b"\x00" * (20 * 1024 * 1024)},
     rejected("compression ratio"), "20 MB of zeros, ratio about 1000:1")

case(F, "57_zip_too_many_files.zip",
     {"tileset.json": tileset(), "tiles/a.glb": GOOD,
      **{f"junk/{i:04d}.txt": "x" for i in range(2001)}},
     rejected("too many files"), "2,003 entries")

# 58: total size over 500 MB, but every single entry stays under the 200:1 ratio
# (random-looking bytes compress badly, so the ZIP itself is big). We fake it
# cheaply: one 600 MB entry of zeros would hit the ratio check first, so instead
# write many 8 MB incompressible chunks... that would make a 500 MB file.
# Instead we patch the declared sizes in the central directory.
buf = io.BytesIO()
with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as z:
    z.writestr("tileset.json", json.dumps(tileset()))
    z.writestr("tiles/a.glb", GOOD)
    z.writestr("big.bin", b"B" * 1024)
data = bytearray(buf.getvalue())
# central directory entry for big.bin: patch compress_size and file_size
idx = data.rfind(b"PK\x01\x02")          # last central dir header = big.bin
struct.pack_into("<II", data, idx + 20, 600 * 1024 * 1024, 600 * 1024 * 1024)
case(F, "58_zip_total_size_over_limit.zip", None, rejected("too large"),
     "Declares 600 MB uncompressed (sizes patched in the header, the file is tiny)", raw=bytes(data))

case(F, "59_no_tileset.zip", {"tiles/a.glb": GOOD}, rejected("No tileset.json"), "ZIP without tileset.json")

case(F, "60_two_tilesets.zip",
     {"a/tileset.json": tileset(), "a/tiles/a.glb": GOOD,
      "b/tileset.json": tileset(), "b/tiles/a.glb": GOOD},
     rejected("More than one tileset.json"), "Two tilesets in one ZIP")

case(F, "61_not_a_zip.zip", None, rejected("Invalid ZIP"),
     "Random bytes with a .zip name", raw=os.urandom(2048))

case(F, "62_empty_file.zip", None, rejected("Invalid ZIP"), "0-byte file", raw=b"")

# 63 uses a different extension, handled specially by the runner
(OUT / F).mkdir(parents=True, exist_ok=True)
write_zip(f"{F}/63_wrong_extension.rar", {"tileset.json": tileset(), "tiles/a.glb": GOOD})
CASES.append({"zip": f"{F}/63_wrong_extension.rar", **rejected("Please upload a ZIP"),
              "note": "Valid ZIP content, but the name doesn't end with .zip"})


# ================================================== 5. should be rejected: tileset.json

F = "5_rejected_tileset"


def bad_tileset(name, content, note):
    case(F, name, {"tileset.json": content, "tiles/a.glb": GOOD}, rejected("Invalid tileset.json"), note)


bad_tileset("70_tileset_invalid_json.zip", '{"asset": {"version": "1.1"}, "root": ', "Cut-off JSON")
bad_tileset("71_tileset_not_utf8.zip", b'{"asset": {"version": "\xff\xfe"}}', "Invalid UTF-8 bytes")
bad_tileset("72_tileset_is_array.zip", [tileset()], "JSON root is a list, not an object")
t = tileset(); del t["root"]
bad_tileset("73_tileset_missing_root.zip", t, "No root")
t = tileset(); del t["asset"]
bad_tileset("74_tileset_missing_asset.zip", t, "No asset")
t = tileset(); del t["geometricError"]
bad_tileset("75_tileset_missing_geometric_error.zip", t, "No top-level geometricError")
bad_tileset("76_tileset_negative_geometric_error.zip", tileset(geometricError=-5), "Negative geometricError")
bad_tileset("77_tileset_geometric_error_string.zip", tileset(geometricError="100"), "geometricError is a string")
t = tileset(); t["asset"]["version"] = 1.1
bad_tileset("78_tileset_asset_version_number.zip", t, "asset.version is a number")
t = tileset(); t["root"]["refine"] = "MERGE"
bad_tileset("79_tileset_bad_refine.zip", t, "refine is not ADD or REPLACE")
t = tileset(); del t["root"]["boundingVolume"]
bad_tileset("80_tileset_root_no_bounding_volume.zip", t, "Root without boundingVolume")
t = tileset(); t["root"]["geometricError"] = -1
bad_tileset("81_tileset_root_negative_error.zip", t, "Negative root geometricError")
bad_tileset("82_tileset_root_is_list.zip", tileset(root=[]), "root is a list")
bad_tileset("83_tileset_empty_file.zip", "", "Empty tileset.json")


# ===================================================== 6. should be rejected: GLB structure

F = "6_rejected_glb_structure"


def bad_glb(name, data, note):
    case(F, name, {"tileset.json": tileset(), "tiles/a.glb": data}, rejected("GLB could not be sanitized"), note)


bad_glb("90_glb_empty.zip", b"", "0 bytes")
bad_glb("91_glb_too_small.zip", b"glTF\x02\x00", "Shorter than the 12-byte header")
bad_glb("92_glb_bad_magic.zip", glb(magic=b"gLTF"), "Wrong magic")
bad_glb("93_glb_version_1.zip", glb(version=1), "GLB version 1")
bad_glb("94_glb_length_too_big.zip", glb(length_delta=+100), "Header length larger than the file")
bad_glb("95_glb_length_too_small.zip", glb(length_delta=-8), "Header length smaller than the file")
bad_glb("96_glb_header_only.zip", struct.pack("<4sII", b"glTF", 2, 12), "Valid header, no chunks")

# chunk length not divisible by 4
j = json.dumps(base_gltf()).encode()
j = pad(j, b" ") + b"   "  # 3 extra bytes -> not aligned
body = struct.pack("<I4s", len(j), b"JSON") + j
data = struct.pack("<4sII", b"glTF", 2, 12 + len(body)) + body
bad_glb("97_glb_chunk_not_aligned.zip", data, "JSON chunk length not divisible by 4")

# chunk length pointing past the end of the file
j = pad(json.dumps(base_gltf()).encode(), b" ")
body = struct.pack("<I4s", len(j) + 4000, b"JSON") + j
data = struct.pack("<4sII", b"glTF", 2, 12 + len(body)) + body
bad_glb("98_glb_chunk_past_end.zip", data, "Chunk length larger than the remaining data")

# BIN chunk first
b = pad(triangle_bin(), b"\x00")
j = pad(json.dumps(base_gltf()).encode(), b" ")
body = chunk(b, b"BIN\x00") + chunk(j, b"JSON")
bad_glb("99_glb_bin_first.zip", struct.pack("<4sII", b"glTF", 2, 12 + len(body)) + body, "First chunk is BIN, not JSON")

bad_glb("100_glb_two_bin_chunks.zip", glb(extra_chunks=chunk(pad(triangle_bin(), b"\x00"), b"BIN\x00")),
        "Two BIN chunks")
bad_glb("101_glb_invalid_json.zip", glb(json_bytes=b'{"asset": {"version": "2.0"'), "Cut-off JSON in the chunk")
bad_glb("102_glb_invalid_utf8.zip", glb(json_bytes=b'{"asset": {"version": "2.0", "x": "\xff\xfe"}}'),
        "Invalid UTF-8 in the JSON chunk")
bad_glb("103_glb_json_is_array.zip", glb(json_bytes=b'[{"asset": {"version": "2.0"}}]', bin_data=b""),
        "JSON root is a list")
g = base_gltf(); del g["asset"]
bad_glb("104_glb_missing_asset.zip", glb(g), "No asset")
g = base_gltf(); g["asset"] = "2.0"
bad_glb("105_glb_asset_not_object.zip", glb(g), "asset is a string")
g = base_gltf(); del g["asset"]["version"]
bad_glb("106_glb_missing_version.zip", glb(g), "No asset.version")
g = base_gltf(); g["asset"]["version"] = "1.0"
bad_glb("107_glb_gltf_version_1.zip", glb(g), "glTF 1.0 inside a GLB 2 container")
g = base_gltf(); g["asset"]["version"] = 2.0
bad_glb("108_glb_version_is_number.zip", glb(g), "asset.version is a number, not a string")
g = base_gltf(); g["buffers"] = {"byteLength": 36}
bad_glb("109_glb_buffers_not_list.zip", glb(g), "buffers is an object")
g = base_gltf(); g["buffers"] = [{}]
bad_glb("110_glb_buffer_no_bytelength.zip", glb(g), "Buffer without byteLength")
g = base_gltf(); g["buffers"] = [{"byteLength": -1}]
bad_glb("111_glb_buffer_negative_length.zip", glb(g), "Negative byteLength")
g = base_gltf(); g["buffers"][0]["uri"] = "https://evil.example.com/data.bin"
bad_glb("112_glb_first_buffer_external_uri.zip", glb(g), "First buffer has an external uri")
bad_glb("113_glb_buffer_bigger_than_bin.zip", glb(base_gltf(bin_length=4096)),
        "Buffer declares 4096 bytes, BIN has 36")
bad_glb("114_glb_buffer_smaller_than_bin.zip", glb(base_gltf(bin_length=8)),
        "Buffer declares 8 bytes, BIN has 36")
bad_glb("115_glb_missing_bin_chunk.zip", glb(base_gltf(), bin_data=b""),
        "Buffer declares 36 bytes, no BIN chunk")
g = base_gltf(); g["bufferViews"][0]["byteLength"] = 10_000
bad_glb("116_glb_bufferview_out_of_bounds.zip", glb(g), "bufferView reads past the buffer")
g = base_gltf(); g["bufferViews"][0]["byteOffset"] = 30
bad_glb("117_glb_bufferview_offset_overflow.zip", glb(g), "offset 30 + length 36 > 36")
g = base_gltf(); g["bufferViews"][0]["byteOffset"] = -4
bad_glb("118_glb_bufferview_negative_offset.zip", glb(g), "Negative byteOffset")
g = base_gltf(); g["bufferViews"][0]["buffer"] = 5
bad_glb("119_glb_bufferview_bad_buffer_index.zip", glb(g), "bufferView points to buffer 5, only 1 exists")
g = base_gltf(); g["bufferViews"][0]["buffer"] = "0"
bad_glb("120_glb_bufferview_index_string.zip", glb(g), "Buffer index is a string")
g = base_gltf(); g["bufferViews"] = [36]
bad_glb("121_glb_bufferview_not_object.zip", glb(g), "bufferView is a number")
g = base_gltf(); del g["bufferViews"][0]["byteLength"]
bad_glb("122_glb_bufferview_no_length.zip", glb(g), "bufferView without byteLength")
case(F, "123_glb_is_actually_png.zip",
     {"tileset.json": tileset(), "tiles/a.glb": b"\x89PNG\r\n\x1a\n" + b"\x00" * 64},
     rejected("GLB could not be sanitized"), "A PNG renamed to .glb")


# ================================================ 7. known gaps (scanner does NOT catch these)

F = "7_known_gaps"


def gap(name, files, note, expect=None):
    case(F, name, files, {**(expect or {"status": 200}), "gap": True}, note)


t = tileset()
t["root"]["extras"] = {"label": "<script>alert('tileset')</script>"}
gap("130_gap_xss_in_tileset_json.zip", {"tileset.json": t, "tiles/a.glb": GOOD},
    "XSS in tileset.json strings is not scanned (only GLB JSON is)")

g = base_gltf()
g["extras"] = {"<script>alert(1)</script>": "key, not value"}
gap("131_gap_xss_in_json_key.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "Script in a JSON key, the scanner only checks values")

g = base_gltf()
g["nodes"][0]["name"] = "&lt;script&gt;alert(1)&lt;/script&gt;"
gap("132_gap_html_entities.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "HTML-entity encoded script, dangerous if a viewer decodes entities")

g = base_gltf()
g["images"] = [{"uri": "https://evil.example.com/tracker.png"}]
gap("134_gap_external_image_uri_in_glb.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "External image uri inside the GLB is not checked")

g = base_gltf()
g["buffers"].append({"uri": "../../etc/passwd", "byteLength": 10})
gap("135_gap_second_buffer_traversal.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "Only the first buffer is checked for a uri")

g = base_gltf()
g["accessors"][0]["count"] = 100_000_000
gap("136_gap_accessor_count_overflow.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "Accessor reads 1.2 GB from a 36-byte bufferView: accessors aren't validated")

g = base_gltf()
g["bufferViews"][0]["byteStride"] = 252
gap("137_gap_bytestride_too_large.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "byteStride larger than the bufferView")

g = base_gltf()
g["meshes"][0]["primitives"][0]["attributes"]["POSITION"] = 99
gap("138_gap_bad_accessor_index.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "Primitive points to accessor 99, which doesn't exist")

sub = tileset(root_with([], uri="https://evil.example.com/x.glb"))
gap("139_gap_nested_external_tileset.zip",
    {"tileset.json": tileset(root_with([tile("sub/external.json")])), "tiles/a.glb": GOOD,
     "sub/external.json": sub},
    "Nested tileset is copied without scanning, its bad uri survives",
    {"status": 200, "not_scanned": 1})

gap("140_gap_malicious_b3dm.zip",
    {"tileset.json": tileset(root_with([tile("tiles/evil.b3dm")])), "tiles/a.glb": GOOD,
     "tiles/evil.b3dm": b"b3dm\x01\x00\x00\x00" + b"\xff" * 64},
    "Broken B3DM is copied as is", {"status": 200, "not_scanned": 1})

deep = tile("tiles/a.glb")
for _ in range(300):
    deep = tile(None, [deep])
gap("141_gap_deep_tree_recursion.zip",
    {"tileset.json": tileset(root_with([deep])), "tiles/a.glb": GOOD},
    "300-level tile tree: recursion works, but there is no depth limit")

deep = "x"
for _ in range(600):
    deep = [deep]
g = base_gltf()
g["extras"] = {"deep": deep}
gap("142_gap_deep_json_in_glb.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "600 nested lists in the GLB JSON: close to Python's recursion limit")

g = base_gltf()
g["extensionsRequired"] = ["EVIL_unknown_extension"]
g["extensionsUsed"] = ["EVIL_unknown_extension"]
gap("143_gap_unknown_required_extension.zip", {"tileset.json": tileset(), "tiles/a.glb": glb(g)},
    "Unknown required extension, no allowlist yet")


# ====================================================================== write

CASES.sort(key=lambda c: c["zip"].split("/")[0])  # keep the groups together

with open(OUT / "expected.json", "w", encoding="utf-8") as f:
    json.dump(CASES, f, indent=2, ensure_ascii=False)

print(f"Created {len(CASES)} test cases in {OUT}/")

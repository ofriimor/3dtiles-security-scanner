# Scanner test suite

124 ZIP files, each one aimed at a single check in the scanner.

| Folder | What it tests | Expected result |
|---|---|---|
| `1_clean` | Valid packages, edge cases that must NOT be touched | 200, nothing removed |
| `2_sanitized_tileset` | Bad `content.uri` values | 200, the reference is removed |
| `3_sanitized_glb_xss` | Script patterns in the GLB JSON | 200, the value is removed |
| `4_rejected_zip` | Zip Slip, symlinks, encryption, ZIP bombs, wrong input | 400 |
| `5_rejected_tileset` | Broken `tileset.json` structure | 400 |
| `6_rejected_glb_structure` | Broken GLB 2.0 binary or JSON | 400 |
| `7_known_gaps` | Attacks the scanner does not catch yet | reported as GAP |

## Run

Start the scanner (Docker or uvicorn), then:

```
python run_tests.py
```

Other options:

```
python run_tests.py --only 6_rejected_glb      # one group
python run_tests.py --url http://localhost:9000/tileset-scanner/
```

To rebuild the ZIPs: `python make_test_zips.py`

The expected result of every ZIP is in `test_zips/expected.json`.

## Safety

The ZIP bomb tests are small: `56` is 20 MB of zeros, and `58` only *declares* 600 MB in its header. If the scanner works, nothing large is ever written to disk.
